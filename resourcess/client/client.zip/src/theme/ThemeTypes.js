export const BODY_LOGIN_SHOW = 'body_login_show';
export const BODY_LOGIN_HIDE = 'body_login_hide';