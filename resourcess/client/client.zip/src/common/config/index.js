export const SERVER_URL = 'http://localhost:4000';
export const DEFAULT_URL = '/primaCare/public';