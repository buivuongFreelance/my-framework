export const ON_CHANGE_FIELD = 'on_change_field';
export const ON_FOCUS_FIELD = 'on_focus_field';
export const ON_VALIDATION_FIELD = 'on_validation_field';